// Core singleton
export class MobileImprovementsCore {
}
