// WindowManager is a singleton that allows management of application windows
export function activate() {
    if (!window.WindowManager) {
        window.WindowManager = new WindowManager();
    }
}
export function getManager() {
    if (!window.WindowManager) {
        activate();
    }
    return window.WindowManager;
}
export class Window {
    constructor(app) {
        this.app = app;
    }
    get title() {
        return this.app.title;
    }
    get id() {
        return this.app.appId;
    }
    get minimized() {
        // @ts-ignore
        return this.app._minimized;
    }
    _floatToTop(element) {
        let z = parseInt(window.document.defaultView.getComputedStyle(element).zIndex);
        if (z < _maxZ) {
            element.style.zIndex = Math.min(++_maxZ, 9999).toString();
        }
    }
    show() {
        // @ts-ignore
        if (this.app._minimized) {
            // @ts-ignore
            this.app.maximize();
        }
        this._floatToTop(this.app.element.get(0));
    }
    minimize() {
        this.app.minimize();
    }
    close() {
        this.app.close();
    }
}
export class WindowManager {
    constructor() {
        // All windows
        this.windows = {};
        this.version = "1.0";
        this.windowChangeHandler = {
            set: (target, property, value, receiver) => {
                target[property] = value;
                this.windowAdded(parseInt(property));
                // Hook for new window being rendered
                Hooks.once("render" + value.constructor.name, this.newWindowRendered);
                return true;
            },
            deleteProperty: (target, property) => {
                const res = delete target[property];
                setTimeout(() => {
                    this.windowRemoved(parseInt(property));
                }, 1);
                return res;
            },
        };
        this.newWindowRendered = (window, html, data) => {
            Hooks.call("WindowManager:NewRendered", window.appId);
        };
        //@ts-ignore
        ui.windows = new Proxy(ui.windows, this.windowChangeHandler);
        console.info("Window Manager | Initiated");
        Hooks.call("WindowManager:Init");
    }
    windowAdded(appId) {
        //@ts-ignore
        this.windows[appId] = new Window(ui.windows[appId]);
        Hooks.call("WindowManager:Added", appId);
    }
    windowRemoved(appId) {
        delete this.windows[appId];
        Hooks.call("WindowManager:Removed", appId);
    }
    minimizeAll() {
        let didMinimize = false;
        Object.entries(this.windows).forEach(([id, window]) => {
            didMinimize = didMinimize || !window.minimized;
            window.minimize();
        });
        return didMinimize;
    }
    closeAll() {
        const closed = Object.keys(this.windows).length != 0;
        Object.entries(this.windows).forEach(([id, window]) => {
            window.close();
        });
        return closed;
    }
}
