import { MODULE_NAME } from "../settings.js";
import { settings, getSetting } from "../settings.js";
var ViewState;
(function (ViewState) {
    ViewState[ViewState["Map"] = 0] = "Map";
    ViewState[ViewState["Sidebar"] = 1] = "Sidebar";
})(ViewState || (ViewState = {}));
var DrawerState;
(function (DrawerState) {
    DrawerState[DrawerState["None"] = 0] = "None";
    DrawerState["Macros"] = "macros";
    DrawerState["Menu"] = "menu";
    DrawerState["Windows"] = "windows";
})(DrawerState || (DrawerState = {}));
export class MobileNavigation extends Application {
    constructor() {
        super({
            //template: "modules/mobile-improvements/templates/navigation.html",
            template: `/modules/${MODULE_NAME}/templates/system-compatibility/base/navigation.html`,
            popOut: false,
        });
        this.state = ViewState.Map;
        this.drawerState = DrawerState.None;
        // Ensure HUD shows on opening a new window
        Hooks.on("WindowManager:NewRendered", () => {
            $(document.body).removeClass("hide-hud");
        });
    }
    get elem() {
        return this.element;
    }
    activateListeners(html) {
        html.find("li").click((evt, as) => {
            const [firstClass] = evt.currentTarget.className.split(" ");
            const [_, name] = firstClass.split("-");
            this.selectItem(name);
        });
        this.updateMode();
    }
    showMap() {
        const minimized = window.WindowManager.minimizeAll();
        console.log(minimized);
        this.state = ViewState.Map;
        //@ts-ignore
        canvas.app.start();
    }
    showSidebar() {
        this.state = ViewState.Sidebar;
        $(document.body).removeClass("hide-hud");
        ui.sidebar.expand();
        window.WindowManager.minimizeAll();
        if (getSetting(settings.SIDEBAR_PAUSES_RENDER) === true) {
            //@ts-ignore
            canvas.app.stop();
        }
    }
    showHotbar() {
        $(document.body).addClass("show-hotbar");
        ui.hotbar.expand();
    }
    hideHotbar() {
        $(document.body).removeClass("show-hotbar");
    }
    setWindowCount(count) {
        this.elem.find(".navigation-windows span span").html(count.toString());
    }
    setDrawerState(state) {
        $(`body > .drawer`).removeClass("open");
        this.elem.find(".toggle.active").removeClass("active");
        this.hideHotbar();
        if (state == DrawerState.None || state == this.drawerState) {
            this.drawerState = DrawerState.None;
            return;
        }
        this.drawerState = state;
        if (state == DrawerState.Macros) {
            this.showHotbar();
        }
        else {
            console.log(state);
            $(`body > .drawer.drawer-${state}`).addClass("open");
        }
        this.elem.find(`.navigation-${state}`).addClass("active");
    }
    selectItem(name) {
        console.log(name);
        switch (name) {
            case "map":
                this.showMap();
                this.setDrawerState(DrawerState.None);
                break;
            case "sidebar":
                this.showSidebar();
                this.setDrawerState(DrawerState.None);
                break;
            default:
                this.setDrawerState(name);
        }
        this.updateMode();
    }
    updateMode() {
        this.elem.find(".active:not(.toggle)").removeClass("active");
        $(document.body).removeClass("show-sidebar");
        switch (this.state) {
            case ViewState.Map:
                this.elem.find(".navigation-map").addClass("active");
                break;
            case ViewState.Sidebar:
                this.elem.find(".navigation-sidebar").addClass("active");
                $(document.body).addClass("show-sidebar");
                break;
            default:
                break;
        }
    }
}
